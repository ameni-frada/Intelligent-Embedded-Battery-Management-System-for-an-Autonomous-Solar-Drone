import math
import random
import time

try:
    from pymavlink import mavutil
except Exception as exc:
    raise SystemExit(f"pymavlink is required: {exc}")

TARGET = "udpout:127.0.0.1:14550"
TAKEOFF_TIME = 120
CLIMB_TIME = 180
CRUISE_TIME = 2400
RETURN_TIME = 300
TOTAL_TIME = TAKEOFF_TIME + CLIMB_TIME + CRUISE_TIME + RETURN_TIME

HOVER = 0
CRUISE = 1
CLIMB = 2
DESCENT = 3
EMERGENCY = 4
SCENARIO_NORMAL = 0

mission_time = 0
altitude = 0.0
wind_angle = random.uniform(0, 2 * math.pi)

print("Pixhawk MAVLink simulator started...")
conn = mavutil.mavlink_connection(TARGET)
boot_ms = 0


def send_named_float(name, value):
    global boot_ms
    boot_ms = (boot_ms + 100) % (2**32)
    conn.mav.named_value_float_send(boot_ms, name.encode("ascii"), float(value))


while True:
    if mission_time < TAKEOFF_TIME:
        flight_mode = CLIMB
        speed = random.uniform(2.5, 4.5)
        altitude += random.uniform(0.70, 0.95)
        altitude = min(90, altitude)
        wind_speed = random.uniform(0.5, 2.0)
    elif mission_time < TAKEOFF_TIME + CLIMB_TIME:
        flight_mode = CLIMB
        speed = random.uniform(5, 8)
        altitude += random.uniform(0.18, 0.35)
        altitude = min(120, altitude)
        wind_speed = random.uniform(1, 3)
    elif mission_time < TAKEOFF_TIME + CLIMB_TIME + CRUISE_TIME:
        flight_mode = CRUISE
        speed = random.uniform(12, 15)
        altitude += random.uniform(-0.10, 0.10)
        altitude = max(118, min(120, altitude))
        wind_speed = random.uniform(2, 6)
    elif mission_time < TOTAL_TIME:
        flight_mode = DESCENT
        speed = random.uniform(6, 9)
        altitude -= random.uniform(0.35, 0.55)
        altitude = max(0, altitude)
        wind_speed = random.uniform(1, 4)
    else:
        mission_time = 0
        altitude = 0
        continue

    wind_angle += random.uniform(-0.08, 0.08)
    if wind_angle > 2 * math.pi:
        wind_angle -= 2 * math.pi
    if wind_angle < 0:
        wind_angle += 2 * math.pi
    wind_angle_cos = math.cos(wind_angle)

    send_named_float("speed_ms", round(speed, 2))
    send_named_float("altitude_m", round(altitude, 2))
    send_named_float("wind_speed_ms", round(wind_speed, 2))
    send_named_float("wind_angle_cos", round(wind_angle_cos, 3))
    send_named_float("flight_mode_code", float(flight_mode))
    send_named_float("scenario_type", float(SCENARIO_NORMAL))

    print({
        "Speed_ms": round(speed, 2),
        "Altitude_m": round(altitude, 2),
        "FlightMode": flight_mode,
        "WindSpeed_ms": round(wind_speed, 2),
        "WindAngle_cos": round(wind_angle_cos, 3),
        "scenario_type": SCENARIO_NORMAL,
    })

    mission_time += 1
    time.sleep(1)
