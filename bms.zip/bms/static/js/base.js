// Base JS — clock, sidebar
function toggleSidebar() {
  document.getElementById("sidebar").classList.toggle("open");
}

(function clock() {
  const el = document.getElementById("topClock");
  if (!el) return;
  setInterval(() => {
    el.textContent = new Date().toLocaleTimeString("en-GB", { hour12: false });
  }, 1000);
})();
