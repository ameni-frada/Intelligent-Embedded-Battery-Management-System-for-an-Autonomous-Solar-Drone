"use strict";

const POLL_MS   = 1000;
let winSize     = 60;
let manualOn    = false;
let pollTimer   = null;
let totalChecks = 0;

// ── Presets (4 ML variables + 2 health metrics) ────────────────
const PRESETS = {
  normal:   { current:11.5, voltage:15.2, power:175, irradiance:700, mppt_eff:0.93, soh_deg_rate:0.004 },
  warning:  { current:24.0, voltage:13.8, power:331, irradiance:400, mppt_eff:0.89, soh_deg_rate:0.009 },
  critical: { current:31.5, voltage:12.4, power:391, irradiance:150, mppt_eff:0.84, soh_deg_rate:0.018 },
  overheat: { current:19.0, voltage:14.6, power:277, irradiance:300, mppt_eff:0.87, soh_deg_rate:0.007 },
  lowsun:   { current:10.0, voltage:14.9, power:149, irradiance:60,  mppt_eff:0.95, soh_deg_rate:0.003 },
};

const hist = { labels:[], score:[], current:[], voltage:[], power:[], irradiance:[], mppt:[], soh:[] };

// ── Charts ────────────────────────────────────────────────────
const OPT = {
  responsive:true, maintainAspectRatio:false, animation:{duration:300},
  interaction:{mode:"nearest",axis:"x",intersect:false},
  plugins:{
    legend:{display:true,labels:{font:{family:"Inter",size:11},color:"#475569",boxWidth:12}},
    tooltip:{backgroundColor:"#fff",borderColor:"#E2E8F0",borderWidth:1,titleColor:"#0F172A",bodyColor:"#475569",padding:10}
  },
  scales:{
    x:{display:false},
    y:{grid:{color:"#F1F5F9",drawBorder:false},
       ticks:{color:"#94A3B8",font:{family:"Inter",size:10},maxTicksLimit:4},
       border:{display:false}}
  }
};

let chartScore, chartTelem;

function initCharts(){
  const ctxS=document.getElementById("chartScore").getContext("2d");
  const gS=ctxS.createLinearGradient(0,0,0,180);
  gS.addColorStop(0,"rgba(220,38,38,0.12)"); gS.addColorStop(1,"rgba(220,38,38,0)");
  chartScore=new Chart(ctxS,{type:"line",data:{labels:hist.labels,datasets:[
    {label:"IF Score",data:hist.score,borderColor:"#DC2626",
     backgroundColor:gS,borderWidth:2,pointRadius:0,tension:0.4,fill:true}
  ]},options:{...OPT,scales:{...OPT.scales,
    y:{...OPT.scales.y,min:0,max:1,ticks:{...OPT.scales.y.ticks,callback:v=>v.toFixed(2)}}
  }}});

  const ctxT=document.getElementById("chartTelem").getContext("2d");
  chartTelem=new Chart(ctxT,{type:"line",data:{labels:hist.labels,datasets:[
    {label:"Voltage (V)",data:hist.voltage,borderColor:"#16A34A",
     backgroundColor:"transparent",borderWidth:1.5,pointRadius:0,tension:0.4,yAxisID:"y"},
    {label:"Irradiance (W/m²)",data:hist.irradiance,borderColor:"#0891B2",
     backgroundColor:"transparent",borderWidth:1.5,pointRadius:0,tension:0.4,yAxisID:"y2"},
    {label:"MPPT Efficiency",data:hist.mppt,borderColor:"#F97316",
     backgroundColor:"transparent",borderWidth:1.5,pointRadius:0,tension:0.3,yAxisID:"y3"},
    {label:"SOH Degradation",data:hist.soh,borderColor:"#7C3AED",
     backgroundColor:"transparent",borderWidth:1.2,pointRadius:0,tension:0.3,yAxisID:"y4"},
  ]},options:{...OPT,scales:{...OPT.scales,
    y:{...OPT.scales.y,position:"left"},
    y2:{...OPT.scales.y,position:"right",grid:{display:false}},
    y3:{display:true,position:"right",grid:{display:false},ticks:{color:"#FB923C"}},
    y4:{display:true,position:"right",grid:{display:false},ticks:{color:"#7C3AED"}}
  }}});
}

function pushHist(d){
  const ts=new Date().toLocaleTimeString("en-GB");
  hist.labels.push(ts); hist.score.push(d.score_if);
  hist.current.push(d.current); hist.voltage.push(d.voltage);
  hist.power.push(d.power); hist.irradiance.push(d.irradiance);
  hist.mppt.push(d.mppt_eff);
  hist.soh.push(d.soh_deg_rate);
  Object.keys(hist).forEach(k=>{if(hist[k].length>winSize)hist[k].shift();});
}

function setWin(n,btn){
  winSize=n;
  Object.keys(hist).forEach(k=>{while(hist[k].length>n)hist[k].shift();});
  document.querySelectorAll(".cw-btn").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active");
}

// ── Gauge ─────────────────────────────────────────────────────
function updateGauge(score){
  const fill=document.getElementById("gaugeFill");
  const needle=document.getElementById("gaugeNeedle");
  const scoreEl=document.getElementById("gaugeScore");
  fill.style.strokeDashoffset=283*(1-score);
  fill.style.stroke=score>0.6?"#DC2626":score>0.3?"#D97706":"#16A34A";
  needle.style.transform=`rotate(${-90+score*180}deg)`;
  scoreEl.textContent=score.toFixed(3);
  scoreEl.style.color=score>0.6?"#DC2626":score>0.3?"#D97706":"#16A34A";
}

// ── Rule checker (4 vars) ─────────────────────────────────────
function checkRule(ruleId,statusId,sev){
  const item=document.getElementById(ruleId);
  const stat=document.getElementById(statusId);
  if(!item||!stat) return;
  if(sev==="CRITICAL"){item.className="rule-item fail";stat.textContent="FAIL";}
  else if(sev==="MODERATE"){item.className="rule-item warn";stat.textContent="WARN";}
  else{item.className="rule-item pass";stat.textContent="PASS";}
}

// ── Main UI update ────────────────────────────────────────────
function applyData(d){
  totalChecks++;
  document.getElementById("totalChecks").textContent=totalChecks;
  document.getElementById("bannerTime").textContent=new Date().toLocaleTimeString("en-GB");

  const lvl=d.anomaly_level.toLowerCase();

  // Banner
  const banner=document.getElementById("statusBanner");
  banner.className="status-banner "+(lvl==="normal"?"normal":lvl==="moderate"?"moderate":"critical");
  document.getElementById("bannerOrb").className="banner-orb "+lvl;
  document.getElementById("bannerTitle").textContent=
    d.anomaly?`ANOMALY DETECTED — ${d.anomaly_level}`:"ALL SYSTEMS NORMAL";
  document.getElementById("bannerSub").textContent=
    d.anomaly?d.anomaly_type:"No anomaly — hybrid detection engine running";

  // Gauge
  updateGauge(d.score_if);

  // Severity
  const sev=document.getElementById("sevCircle");
  sev.textContent=d.anomaly_level[0];
  sev.className="sev-circle "+lvl;
  document.getElementById("sevLevelText").textContent=d.anomaly_level;

  ["spNormal","spModerate","spCritical"].forEach(id=>{
    document.getElementById(id).className="sev-pill";
  });
  const map={NORMAL:"spNormal",MODERATE:"spModerate",CRITICAL:"spCritical"};
  if(map[d.anomaly_level]) document.getElementById(map[d.anomaly_level]).className="sev-pill active-"+lvl;

  document.getElementById("anomalyTypeText").textContent=d.anomaly_type;
  document.getElementById("anomalyTypeText").style.color=
    d.anomaly?(d.anomaly_level==="CRITICAL"?"#DC2626":d.anomaly_level==="MODERATE"?"#D97706":""):"";

  const modelBadge = document.getElementById("modelBadge");
  if(modelBadge){
    const mode = d.anomaly_model_mode || "unknown";
    const count = d.anomaly_model_features || "?";
    modelBadge.textContent = `Anomaly model: ${mode.toUpperCase()} (${count} feature${count===1?"":"s"})`;
    modelBadge.className = `banner-badge ${mode}`;
  }

  // Sources
  const setCard=(id,statusId,triggered,sev)=>{
    const cls=triggered?(sev==="CRITICAL"?"triggered-crit":sev==="MODERATE"?"triggered-warn":"triggered"):"";
    const el=document.getElementById(id);
    el.className="source-card "+cls+(id==="srcFusion"?" source-result":"");
    document.getElementById(statusId).textContent=triggered?(sev||"TRIGGERED"):"CLEAR";
  };
  setCard("srcML",    "srcMLStatus",     d.ml_triggered,     d.anomaly?d.anomaly_level:"NORMAL");
  setCard("srcExpert","srcExpertStatus", d.expert_triggered, d.anomaly?d.anomaly_level:"NORMAL");
  setCard("srcFusion","srcFusionStatus", d.anomaly,          d.anomaly_level);

  // Expert rules — health and battery metrics
  const vSev=d.voltage<13.2?"CRITICAL":d.voltage<14.0?"MODERATE":"OK";
  const iSev=d.current>30?"CRITICAL":d.current>25?"MODERATE":"OK";
  const pSev=d.power>500?"CRITICAL":d.power>400?"MODERATE":"OK";
  const rSev=d.irradiance<50?"CRITICAL":d.irradiance<100?"MODERATE":"OK";
  const mSev=d.mppt_eff<0.85?"CRITICAL":d.mppt_eff<0.88?"MODERATE":"OK";
  const sSev=d.soh_deg_rate>0.015?"CRITICAL":d.soh_deg_rate>0.010?"MODERATE":"OK";
  checkRule("rVoltage","rsVoltage",vSev);
  checkRule("rCurrent","rsCurrent",iSev);
  checkRule("rPower",  "rsPower",  pSev);
  checkRule("rIrr",    "rsIrr",    rSev);
  checkRule("rMppt",   "rsMppt",   mSev);
  checkRule("rSoh",    "rsSoh",    sSev);

  // Compact telemetry — 4 ML inputs + 2 health metrics
  const setct=(id,barId,val,warn,crit,dec=1)=>{
    const el=document.getElementById(id);
    if(el){el.textContent=val.toFixed(dec);el.style.color=val>=crit?"#DC2626":val>=warn?"#D97706":"";}
    const bar=document.getElementById(barId);
    if(bar) bar.style.width=Math.min(100,(val/crit)*80).toFixed(1)+"%";
  };
  setct("ctCurr","ctbCurr",d.current,   25,  30,  2);
  setct("ctVolt","ctbVolt",d.voltage,   14.0,13.2,2);
  setct("ctPow", "ctbPow", d.power,     400, 500, 0);
  setct("ctIrr", "ctbIrr", d.irradiance,100, 50,  0);
  setct("ctMppt","ctbMppt",d.mppt_eff,  0.88,0.85,3);
  setct("ctSoh","ctbSoh", d.soh_deg_rate,0.010,0.015,5);

  // Top status dot
  const dot=document.getElementById("topStatusDot");
  const st=document.getElementById("topStatusText");
  if(d.anomaly_level==="CRITICAL")     {dot.className="status-dot red";   st.textContent="CRITICAL ANOMALY";}
  else if(d.anomaly_level==="MODERATE"){dot.className="status-dot yellow";st.textContent="Moderate Warning";}
  else                                 {dot.className="status-dot green"; st.textContent="System Nominal";}

  pushHist(d);
  chartScore.update("none");
  chartTelem.update("none");
}

// ── API ───────────────────────────────────────────────────────
async function fetchAnomaly(body={}){
  const payload = {
    current: body.current ?? 12.4,
    voltage: body.voltage ?? 14.8,
    power: body.power ?? 183,
    irradiance: body.irradiance ?? 650,
    mppt_eff: body.mppt_eff ?? 0.93,
    soh_deg_rate: body.soh_deg_rate ?? 0.005,
  };

  try{
    const r=await fetch("/api/anomaly",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
    if(!r.ok){
      const errorText = await r.text();
      throw new Error(`HTTP ${r.status} ${errorText}`);
    }
    const data = await r.json();
    if(data.error){
      throw new Error(data.error);
    }
    applyData(data);
  }catch(e){
    console.error("[Anomaly]",e);
    const title=document.getElementById("bannerTitle");
    const sub=document.getElementById("bannerSub");
    if(title) title.textContent="Anomaly API error";
    if(sub) sub.textContent=e.message;
  }
}

// ── Manual mode ───────────────────────────────────────────────
function toggleMode(){
  manualOn=!manualOn;
  const panel=document.getElementById("manualPanel");
  const btn=document.getElementById("modeBtn");
  const badge=document.getElementById("autoBadge");
  panel.style.display=manualOn?"block":"none";
  btn.classList.toggle("active",manualOn);
  btn.innerHTML=manualOn
    ?'<i class="bi bi-x-lg"></i> Close Override'
    :'<i class="bi bi-sliders"></i> Manual Override';
  if(manualOn){
    clearInterval(pollTimer);pollTimer=null;
    badge.style.background="#FFF7ED";badge.style.borderColor="#FDE68A";badge.style.color="#D97706";
    badge.innerHTML="<span>Override Mode</span>";
  }else{
    badge.style="";badge.innerHTML='<span class="live-dot"></span> Autonomous Live Stream';
    fetchAnomaly();pollTimer=setInterval(fetchAnomaly,POLL_MS);
  }
}

function loadPreset(name){
  const p=PRESETS[name]; if(!p) return;
  document.getElementById("mCurrent").value    = p.current;
  document.getElementById("mVoltage").value    = p.voltage;
  document.getElementById("mPower").value      = p.power;
  document.getElementById("mIrradiance").value = p.irradiance;
  document.getElementById("mMppt").value       = p.mppt_eff;
  document.getElementById("mSoh").value        = p.soh_deg_rate;
}

async function analyzeManual(){
  const rd=(id,lo,hi)=>{
    const v=parseFloat(document.getElementById(id).value);
    if(isNaN(v)||v<lo||v>hi){document.getElementById(id).classList.add("error");return null;}
    document.getElementById(id).classList.remove("error");return v;
  };
  const current=rd("mCurrent",0,40), voltage=rd("mVoltage",10,18),
        power=rd("mPower",0,600),     irradiance=rd("mIrradiance",0,1200),
        mppt_eff=rd("mMppt",0.80,0.99), soh_deg_rate=rd("mSoh",0,0.05);
  if([current,voltage,power,irradiance,mppt_eff,soh_deg_rate].includes(null)) return;

  const btn=document.getElementById("analyzeBtn");
  btn.classList.add("loading");
  btn.innerHTML='<div style="width:14px;height:14px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;display:inline-block"></div> Analyzing...';

  await fetchAnomaly({current,voltage,power,irradiance, mppt_eff, soh_deg_rate});
  btn.classList.remove("loading");
  btn.innerHTML='<i class="bi bi-cpu-fill"></i> Run Detection';
}

// ── Boot ──────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded",()=>{
  initCharts();
  fetchAnomaly();
  pollTimer=setInterval(fetchAnomaly,POLL_MS);
});
