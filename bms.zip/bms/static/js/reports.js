"use strict";

async function loadReportsSummary(){
  try{
    const r = await fetch('/api/reports/summary');
    const d = await r.json();
    document.getElementById('cardMissions').querySelector('span').textContent = d.total_missions;
    document.getElementById('cardHours').querySelector('span').textContent = d.total_hours;
    document.getElementById('cardEnergy').querySelector('span').textContent = d.avg_power;
    document.getElementById('cardAnoms').querySelector('span').textContent = d.total_anomalies;
    return d;
  }catch(e){console.error(e);}  
}

let chartEnergy, chartHealth;
function initCharts(){
  const ctxE = document.getElementById('chartEnergy').getContext('2d');
  chartEnergy = new Chart(ctxE,{type:'line',data:{labels:[],datasets:[{label:'Energy',data:[],borderColor:'#0EA5A4',backgroundColor:'transparent'}]},options:{responsive:true,maintainAspectRatio:false}});

  const ctxH = document.getElementById('chartHealth').getContext('2d');
  chartHealth = new Chart(ctxH,{type:'line',data:{labels:[],datasets:[{label:'MPPT',data:[],borderColor:'#F97316'},{label:'SOH',data:[],borderColor:'#7C3AED'}]},options:{responsive:true,maintainAspectRatio:false}});
}

async function loadCharts(){
  try{
    const r = await fetch('/api/reports/charts');
    const d = await r.json();
    chartEnergy.data.labels = d.labels; chartEnergy.data.datasets[0].data = d.power; chartEnergy.update();
    chartHealth.data.labels = d.labels; chartHealth.data.datasets[0].data = d.mppt; chartHealth.data.datasets[1].data = d.soh; chartHealth.update();
  }catch(e){console.error(e);}  
}

async function loadMissions(page=1, limit=20, search=''){
  try{
    const r = await fetch(`/api/reports/missions?page=${page}&limit=${limit}&search=${encodeURIComponent(search)}`);
    const d = await r.json();
    const tbody = document.querySelector('#missionsTable tbody'); tbody.innerHTML='';
    d.missions.forEach(m=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${m.mission_id}</td><td>${m.start_time}</td><td>${m.duration_min}</td><td>${m.energy_consumed}</td><td>${m.anomaly_count}</td><td>${m.final_risk}</td><td>${m.status}</td>`;
      tbody.appendChild(tr);
    });
  }catch(e){console.error(e);}  
}

function setupActions(){
  document.getElementById('btnExportCsv').addEventListener('click',()=>{window.location='/api/reports/export/csv';});
  document.getElementById('btnExportJson').addEventListener('click',()=>{window.location='/api/reports/export/json';});
  document.getElementById('searchBox').addEventListener('input',e=>{loadMissions(1,20,e.target.value);});
}

document.addEventListener('DOMContentLoaded',()=>{
  initCharts();
  loadReportsSummary();
  loadCharts();
  loadMissions();
  setupActions();
});
