"use strict";

const POLL_MS  = 1000;
let winSize    = 60;
let manualOn   = false;
let pollTimer  = null;

// ── Presets (10 vars) ────────────────────────────────────────
const PRESETS = {
  normal:   { speed:15, altitude:120, current:11.5, irradiance:700, temperature:30,
              soc:78,  flight_mode:"Cruise",   wind_speed:3,  wind_angle_cos:0.85, scenario_type:"Normal" },
  warning:  { speed:8,  altitude:200, current:24.0, irradiance:400, temperature:43,
              soc:28,  flight_mode:"Climb",    wind_speed:8,  wind_angle_cos:0.4,  scenario_type:"High Wind" },
  critical: { speed:5,  altitude:80,  current:31.5, irradiance:150, temperature:58,
              soc:10,  flight_mode:"Emergency",wind_speed:12, wind_angle_cos:0.1,  scenario_type:"Emergency" },
  lowsun:   { speed:12, altitude:100, current:10.0, irradiance:80,  temperature:28,
              soc:55,  flight_mode:"Cruise",   wind_speed:2,  wind_angle_cos:0.9,  scenario_type:"Low Irradiance" },
  highwind: { speed:20, altitude:150, current:19.0, irradiance:600, temperature:35,
              soc:60,  flight_mode:"Cruise",   wind_speed:15, wind_angle_cos:-0.3, scenario_type:"High Wind" },
};

const hist = { labels:[], soc:[], irradiance:[], wind_speed:[], ft:[], current:[] };

// ── Charts ────────────────────────────────────────────────────
const CHART_OPT = {
  responsive:true, maintainAspectRatio:false, animation:{duration:300},
  interaction:{mode:"nearest",axis:"x",intersect:false},
  plugins:{
    legend:{display:true,labels:{font:{family:"Inter",size:11},color:"#475569",boxWidth:12}},
    tooltip:{backgroundColor:"#fff",borderColor:"#E2E8F0",borderWidth:1,
             titleColor:"#0F172A",bodyColor:"#475569",padding:10}
  },
  scales:{
    x:{display:false},
    y:{grid:{color:"#F1F5F9",drawBorder:false},
       ticks:{color:"#94A3B8",font:{family:"Inter",size:10},maxTicksLimit:5},
       border:{display:false}}
  }
};

function grad(ctx,color,alpha=0.15){
  const g=ctx.createLinearGradient(0,0,0,200);
  g.addColorStop(0,color.replace(")",`,${alpha})`).replace("rgb","rgba"));
  g.addColorStop(1,color.replace(")",",0.00)").replace("rgb","rgba"));
  return g;
}

let chartMain, chartEnv;

function initCharts(){
  const ctxM=document.getElementById("chartMain").getContext("2d");
  chartMain=new Chart(ctxM,{type:"line",data:{labels:hist.labels,datasets:[
    {label:"SoC (%)",data:hist.soc,borderColor:"#2563EB",
     backgroundColor:grad(ctxM,"rgb(37,99,235)"),borderWidth:2,pointRadius:0,tension:0.4,fill:true,yAxisID:"y"},
    {label:"Flight Time (min)",data:hist.ft,borderColor:"#16A34A",
     backgroundColor:"transparent",borderWidth:1.5,pointRadius:0,tension:0.4,borderDash:[4,3],yAxisID:"y2"},
  ]},options:{...CHART_OPT,scales:{...CHART_OPT.scales,
    y:{...CHART_OPT.scales.y,position:"left"},
    y2:{...CHART_OPT.scales.y,position:"right",grid:{display:false}}
  }}});

  const ctxE=document.getElementById("chartEnv").getContext("2d");
  chartEnv=new Chart(ctxE,{type:"line",data:{labels:hist.labels,datasets:[
    {label:"Irradiance (W/m²)",data:hist.irradiance,borderColor:"#0891B2",
     backgroundColor:grad(ctxE,"rgb(8,145,178)"),borderWidth:2,pointRadius:0,tension:0.4,fill:true,yAxisID:"y"},
    {label:"Wind Speed (m/s)",data:hist.wind_speed,borderColor:"#EA580C",
     backgroundColor:"transparent",borderWidth:1.5,pointRadius:0,tension:0.4,yAxisID:"y2"},
  ]},options:{...CHART_OPT,scales:{...CHART_OPT.scales,
    y:{...CHART_OPT.scales.y,position:"left"},
    y2:{...CHART_OPT.scales.y,position:"right",grid:{display:false}}
  }}});
}

function pushHist(d){
  const ts=new Date().toLocaleTimeString("en-GB");
  hist.labels.push(ts); hist.soc.push(d.soc); hist.irradiance.push(d.irradiance);
  hist.wind_speed.push(d.wind_speed); hist.ft.push(d.remaining_time);
  Object.keys(hist).forEach(k=>{if(hist[k].length>winSize)hist[k].shift();});
}

function setWin(n,btn){
  winSize=n;
  Object.keys(hist).forEach(k=>{while(hist[k].length>n)hist[k].shift();});
  document.querySelectorAll(".cw-btn").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active");
}

// ── Helpers ───────────────────────────────────────────────────
const clamp=(v,lo,hi)=>Math.min(Math.max(v,lo),hi);
const pct=(v,lo,hi)=>clamp(((v-lo)/(hi-lo))*100,0,100).toFixed(1)+"%";

function setBar(id,val,lo,hi){
  const el=document.getElementById(id);
  if(el) el.style.width=pct(val,lo,hi);
}

function setTelem(valId,barId,val,lo,hi,warn,crit,unit,dec=1){
  const el=document.getElementById(valId);
  if(!el) return;
  el.innerHTML=val.toFixed(dec)+` <span class="telem-unit">${unit}</span>`;
  el.style.color=val>=crit?"#DC2626":val>=warn?"#D97706":"";
  setBar(barId,val,lo,hi);
}

// ── Main UI update ────────────────────────────────────────────
function applyData(d){
  // KPI cards
  const ft=document.getElementById("kFlight");
  ft.textContent=d.remaining_time; ft.style.color="";

  const socEl=document.getElementById("kSoc");
  socEl.textContent=d.soc.toFixed(1);
  socEl.style.color=d.soc>50?"":d.soc>25?"#D97706":"#DC2626";

  document.getElementById("kIrr").textContent=d.irradiance.toFixed(0);
  setBar("barSoc",d.soc,0,100);
  setBar("barIrr",d.irradiance,0,1000);

  const riskEl=document.getElementById("kRisk");
  riskEl.textContent=d.risk_level;
  riskEl.className="kpi-value risk-value "+d.risk_level.toLowerCase();
  document.getElementById("kRec").textContent=d.recommendation;

  // Flight time ring
  const circ=213.6;
  const off=circ*(1-clamp(d.remaining_time/60,0,1));
  const ring=document.getElementById("ringFlight");
  ring.style.strokeDashoffset=off;
  ring.style.stroke=d.remaining_time>20?"#2563EB":d.remaining_time>10?"#D97706":"#DC2626";

  // Mission telemetry
  setTelem("tSpeed","bSpeed",d.speed,0,50,35,45,"m/s",1);
  setTelem("tAlt","bAlt",d.altitude,0,500,400,480,"m",0);
  document.getElementById("badgeMode").textContent=d.flight_mode||"--";
  document.getElementById("badgeScenario").textContent=d.scenario_type||"--";

  // Environment telemetry
  setTelem("tIrr","bIrr",d.irradiance,0,1200,100,50,"W/m²",0);
  setTelem("tWind","bWind",d.wind_speed,0,20,10,15,"m/s",1);
  const wa=d.wind_angle_cos;
  const waEl=document.getElementById("tWindAngle");
  if(waEl) waEl.innerHTML=wa.toFixed(3)+` <span class="telem-unit"></span>`;
  setBar("bWindAngle",wa,-1,1);

  // Battery telemetry
  setTelem("tSoc","bSoc",d.soc,0,100,25,15,"%",1);
  setTelem("tTemp","bTemp",d.temperature,10,65,45,55,"°C",1);
  setTelem("tCurrent","bCurrent",d.current,0,32,25,30,"A",2);

  // Recommendation
  const iconMap={LOW:"bi bi-check-circle-fill",MEDIUM:"bi bi-exclamation-triangle-fill",HIGH:"bi bi-x-octagon-fill"};
  const recBody=document.getElementById("recBody");
  recBody.className="rec-body "+d.risk_level.toLowerCase();
  document.getElementById("recIcon").innerHTML=`<i class="${iconMap[d.risk_level]||iconMap.LOW}"></i>`;
  document.getElementById("recText").textContent=d.recommendation;

  // Rec summary metrics
  document.getElementById("rmSpeed").textContent=(d.speed||0).toFixed(1)+"m/s";
  document.getElementById("rmAlt").textContent=(d.altitude||0).toFixed(0)+"m";
  document.getElementById("rmIrr").textContent=(d.irradiance||0).toFixed(0)+"W/m²";
  document.getElementById("rmWind").textContent=(d.wind_speed||0).toFixed(1)+"m/s";

  // Top status
  const dot=document.getElementById("topStatusDot");
  const st=document.getElementById("topStatusText");
  if(d.risk_level==="HIGH")        {dot.className="status-dot red";   st.textContent="CRITICAL ALERT";}
  else if(d.risk_level==="MEDIUM") {dot.className="status-dot yellow";st.textContent="Warning Active";}
  else                             {dot.className="status-dot green"; st.textContent="System Nominal";}

  document.getElementById("lastUpdate").textContent=new Date().toLocaleTimeString("en-GB");
  pushHist(d);
  chartMain.update("none");
  chartEnv.update("none");
}

// ── API ───────────────────────────────────────────────────────
async function fetchPrediction(body={}){
  const payload = {
    speed: body.speed ?? 15,
    altitude: body.altitude ?? 120,
    current: body.current ?? 12.4,
    irradiance: body.irradiance ?? 650,
    temperature: body.temperature ?? 30,
    soc: body.soc ?? 78,
    flight_mode: body.flight_mode ?? 'Cruise',
    wind_speed: body.wind_speed ?? 3,
    wind_angle_cos: body.wind_angle_cos ?? 0.85,
    scenario_type: body.scenario_type ?? 'Normal',
    voltage: body.voltage ?? 14.8,
    power: body.power ?? 183,
    mppt_eff: body.mppt_eff ?? 0.92,
    soh_deg_rate: body.soh_deg_rate ?? 0.005,
  };

  try{
    const r=await fetch("/api/predict",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
    if(!r.ok){
      const errorText = await r.text();
      throw new Error(`HTTP ${r.status} ${errorText}`);
    }
    const data = await r.json();
    if(data.error){
      throw new Error(data.error);
    }
    applyData(data);
  }catch(e){
    console.error("[Prediction]",e);
    const msg=document.getElementById("recText");
    if(msg) msg.textContent=`Prediction error: ${e.message}`;
  }
}

// ── Manual mode ───────────────────────────────────────────────
function toggleMode(){
  manualOn=!manualOn;
  const panel=document.getElementById("manualPanel");
  const btn=document.getElementById("modeBtn");
  const badge=document.getElementById("autoBadge");
  panel.style.display=manualOn?"block":"none";
  btn.classList.toggle("active",manualOn);
  btn.innerHTML=manualOn
    ?'<i class="bi bi-x-lg"></i> Close Override'
    :'<i class="bi bi-sliders"></i> Manual Override';
  if(manualOn){
    clearInterval(pollTimer);pollTimer=null;
    badge.style.background="#FFF7ED";badge.style.borderColor="#FDE68A";badge.style.color="#D97706";
    badge.innerHTML="<span>Override Mode</span>";
  }else{
    badge.style="";badge.innerHTML='<span class="live-dot"></span> Autonomous Live Stream';
    fetchPrediction();pollTimer=setInterval(fetchPrediction,POLL_MS);
  }
}

function loadPreset(name){
  const p=PRESETS[name]; if(!p) return;
  document.getElementById("mSpeed").value        = p.speed;
  document.getElementById("mAltitude").value     = p.altitude;
  document.getElementById("mCurrent").value      = p.current;
  document.getElementById("mIrradiance").value   = p.irradiance;
  document.getElementById("mTemp").value         = p.temperature;
  document.getElementById("mSoc").value          = p.soc;
  document.getElementById("mFlightMode").value   = p.flight_mode;
  document.getElementById("mWindSpeed").value    = p.wind_speed;
  document.getElementById("mWindAngle").value    = p.wind_angle_cos;
  document.getElementById("mScenario").value     = p.scenario_type;
}

function rd(id,lo,hi){
  const v=parseFloat(document.getElementById(id).value);
  if(isNaN(v)||v<lo||v>hi){document.getElementById(id).classList.add("error");return null;}
  document.getElementById(id).classList.remove("error"); return v;
}

async function analyzeManual(){
  const speed         = rd("mSpeed",        0,   50);
  const altitude      = rd("mAltitude",     0,   500);
  const current       = rd("mCurrent",      0,   40);
  const irradiance    = rd("mIrradiance",   0,   1200);
  const temperature   = rd("mTemp",        -10,  80);
  const soc           = rd("mSoc",          0,   100);
  const wind_speed    = rd("mWindSpeed",    0,   20);
  const wind_angle_cos= rd("mWindAngle",   -1,   1);
  const flight_mode   = document.getElementById("mFlightMode").value;
  const scenario_type = document.getElementById("mScenario").value;

  if([speed,altitude,current,irradiance,temperature,soc,wind_speed,wind_angle_cos].includes(null)) return;

  const btn=document.getElementById("analyzeBtn");
  btn.classList.add("loading");
  btn.innerHTML='<div style="width:14px;height:14px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;display:inline-block"></div> Analyzing...';

  await fetchPrediction({speed,altitude,current,irradiance,temperature,
                         soc,flight_mode,wind_speed,wind_angle_cos,scenario_type});
  btn.classList.remove("loading");
  btn.innerHTML='<i class="bi bi-cpu-fill"></i> Run Prediction';
}

// ── Boot ──────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded",()=>{
  initCharts();
  fetchPrediction();
  pollTimer=setInterval(fetchPrediction,POLL_MS);
});
