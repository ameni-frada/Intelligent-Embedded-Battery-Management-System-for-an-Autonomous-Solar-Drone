import json
import socket
import sys
import time
 
try:
    import serial
except Exception as exc:
    print(f"[STM32] pyserial requis: {exc}")
    sys.exit(1)
 
HOST = "127.0.0.1"
PORT = 5005
SERIAL_PORT = "COM3"          # adapter selon l'environnement
BAUD_RATE = 115200
TIMEOUT = 1.0
MAX_BUFFER_SIZE = 8192          # garde-fou anti fuite mémoire si jamais de '\n'
 
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
 
 
# ─────────────────────────────────────────────
# Normalisation : format STM32 réel -> format backend
# ─────────────────────────────────────────────
def normalize(payload: dict):
    """
    STM32 envoie (format réel, mesuré sur le hardware) :
        Vpv, Ipv, Ppv, Duty, SOC, SOH, Mission
 
    Le backend attend (clés de normalize_stm32_payload côté Flask) :
        Voltage_V, Current_A, SoC_pct, MPPT_eff, SOH_deg_rate
 
    IMPORTANT : on n'inclut PAS BatteryTemp_C / Irradiance_Wm2 ici car le
    STM32 ne les mesure pas. Le backend doit les compléter via la
    simulation/sa propre estimation plutôt que de recevoir un faux 0.0
    qui écraserait la valeur simulée (bug corrigé côté app.py).
    """
    try:
        out = {
            "Voltage_V": float(payload.get("Vpv", 0.0)),
            "Current_A": float(payload.get("Ipv", 0.0)),
            "SoC_pct": float(payload.get("SOC", 0.0)),
            "MPPT_eff": float(payload.get("Duty", 0.92)),
            "SOH_deg_rate": float(payload.get("SOH", 0.005)) / 1000.0
                if float(payload.get("SOH", 0.005)) > 1
                else float(payload.get("SOH", 0.005)),
            "Mission": int(payload.get("Mission", 0)),
        }
        # Power_W n'est pas transmis : il est recalculé côté backend comme
        # Voltage_V * Current_A pour garantir la cohérence (évite la dérive
        # entre une puissance mesurée et une puissance recalculée).
        return out
    except Exception as e:
        print("[STM32] erreur de normalisation:", e, "payload brut:", payload)
        return None
 
 
# ─────────────────────────────────────────────
# Extraction robuste de trames JSON depuis un buffer
# (gère le cas où une trame est coupée sur deux readline())
# ─────────────────────────────────────────────
def extract_json_objects(buffer: str):
    """
    Retourne (liste_objets_parsés, reste_du_buffer).
    Cherche des objets { ... } complets et bien équilibrés.
    """
    objects = []
    depth = 0
    start = None
    for i, ch in enumerate(buffer):
        if ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            if depth > 0:
                depth -= 1
                if depth == 0 and start is not None:
                    chunk = buffer[start:i + 1]
                    try:
                        objects.append(json.loads(chunk))
                    except json.JSONDecodeError:
                        print("[STM32] JSON invalide ignoré:", chunk)
                    start = None
    # ce qui reste après le dernier objet complet
    if start is not None:
        remainder = buffer[start:]
    else:
        remainder = ""
    return objects, remainder
 
 
# ─────────────────────────────────────────────
# Boucle principale
# ─────────────────────────────────────────────
def read_and_forward():
    buffer = ""
    while True:
        try:
            with serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=TIMEOUT) as ser:
                print(f"[STM32] Connecté sur {SERIAL_PORT}")
                buffer = ""
 
                while True:
                    raw_bytes = ser.readline()
                    if not raw_bytes:
                        continue
 
                    try:
                        chunk = raw_bytes.decode("utf-8", errors="ignore")
                    except Exception:
                        continue
 
                    buffer += chunk
                    if len(buffer) > MAX_BUFFER_SIZE:
                        print("[STM32] buffer trop grand, reset (trame corrompue)")
                        buffer = ""
                        continue
 
                    objects, buffer = extract_json_objects(buffer)
 
                    for data in objects:
                        normalized = normalize(data)
                        if normalized is None:
                            continue
                        try:
                            sock.sendto(
                                json.dumps(normalized).encode("utf-8"),
                                (HOST, PORT)
                            )
                            print("[STM32] envoyé:", normalized)
                        except Exception as e:
                            print("[STM32] erreur UDP:", e)
 
        except serial.SerialException as e:
            print(f"[STM32] erreur série ({SERIAL_PORT}): {e} — reconnexion dans 2s")
            time.sleep(2)
        except Exception as e:
            print("[STM32] erreur inattendue:", e)
            time.sleep(2)
 
 
if __name__ == "__main__":
    read_and_forward()
 