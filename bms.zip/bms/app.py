"""
=============================================================================
  Intelligent BMS — Solar Drone  |  Enterprise Flask App  v3.0
  Pages: Login · Energy Prediction (10 vars) · Anomaly Detection (6 vars)
         Reports · Settings
=============================================================================
"""

import os, random, math, csv, json, sqlite3, traceback, threading, time, socket
import numpy as np
from functools import wraps
from flask import (Flask, request, jsonify, render_template,
                   redirect, url_for, session, send_file)
from datetime import datetime, timedelta
from io import StringIO, BytesIO
from collections import deque

app = Flask(__name__)
app.secret_key = "bms-solar-drone-2025"

# ── Autonomous telemetry pipeline ────────────────────────────────────────
PIXHAWK_UDP_PORT = 5006
STM32_UDP_PORT = 5005
MAVLINK_UDP_PORT = 14550
STATE_LOCK = threading.Lock()
LIVE_HISTORY = deque(maxlen=180)
_background_started = False

drone_state = {
    "battery": {
        "voltage": 15.2,
        "current": 12.0,
        "power": 182.4,
        "soc": 78.0,
        "mppt_eff": 0.93,
        "soh_deg_rate": 0.004,
        "mission": 0,
        "timestamp": None,
    },
    "flight": {
        "speed": 15.0,
        "altitude": 120.0,
        "flight_mode": "Cruise",
        "wind_speed": 3.0,
        "wind_angle_cos": 0.85,
        "scenario_type": "Normal",
        "timestamp": None,
    },
    "ai": {
        "remaining_energy": None,
        "remaining_time": None,
        "remaining_pct": None,
        "risk_level": "LOW",
        "recommendation": "Nominal flight — all systems optimal",
        "anomaly": False,
        "anomaly_level": "NORMAL",
        "anomaly_type": "No anomaly detected",
        "score_if": 0.0,
        "ml_triggered": False,
        "expert_triggered": False,
    },
    "meta": {
        "last_pixhawk": None,
        "last_stm32": None,
        "last_ai_update": None,
        "source": "simulation",
    },
}

# ── Paths ──────────────────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(__file__)
MODELS_DIR  = os.path.join(BASE_DIR, "models")
DB_PATH     = os.path.join(BASE_DIR, "database", "bms.db")
DATA_DIR    = os.path.join(BASE_DIR, "data")
EXPORTS_DIR = os.path.join(BASE_DIR, "static", "exports")
SETTINGS_FILE = os.path.join(BASE_DIR, "database", "settings.json")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(EXPORTS_DIR, exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, "database"), exist_ok=True)

# ── Demo users ─────────────────────────────────────────────────────────────
USERS = {
    "admin":   {"password": "admin123",  "role": "System Engineer",  "full_name": "Admin BMS",      "email": "admin@bms.pro"},
    "pilot":   {"password": "pilot2025", "role": "Drone Pilot",      "full_name": "Pilot Alpha",    "email": "pilot@bms.pro"},
    "analyst": {"password": "analyst1",  "role": "Energy Analyst",   "full_name": "Energy Analyst", "email": "analyst@bms.pro"},
}

# ── Default Settings ───────────────────────────────────────────────────────
DEFAULT_SETTINGS = {
    "profile": {"name": "Admin BMS", "role": "System Engineer", "email": "admin@bms.pro"},
    "bms": {
        "v_warn": 14.0, "v_crit": 13.2,
        "i_warn": 25.0, "i_crit": 30.0,
        "t_warn": 45.0, "t_crit": 55.0,
        "soc_warn": 25.0, "soc_crit": 15.0,
        "irr_low": 100.0,
        "mppt_warn": 0.88, "mppt_crit": 0.85,
        "soh_warn": 0.010, "soh_crit": 0.015
    },
    "ai": {
        "pred_engine": True,
        "isolation_forest": True,
        "expert_rules": True,
        "pred_interval": 1000,
        "anom_interval": 1000
    },
    "simulation": {
        "enabled": True,
        "irradiance_profile": "sunny",
        "wind_profile": "moderate",
        "battery_aging": "normal"
    },
    "appearance": {"theme": "light"}
}

def load_settings():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return dict(DEFAULT_SETTINGS)

def save_settings(s):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(s, f, indent=2)

# ── Model loading ──────────────────────────────────────────────────────────
pred_model  = None
pred_scaler = None
anom_model  = None
anom_scaler = None
ANOMALY_FEATURE_COUNT = None
SIMULATION_MODE = False

def load_models():
    global pred_model, pred_scaler, anom_model, anom_scaler, ANOMALY_FEATURE_COUNT, SIMULATION_MODE
    try:
        import joblib
        files = ["best_prediction_model.pkl", "prediction_scaler.pkl",
                 "bms_isolation_forest.pkl", "bms_scaler_anomalies.pkl"]
        if not all(os.path.exists(os.path.join(MODELS_DIR, f)) for f in files):
            print("[BMS] Model files not found → SIMULATION MODE")
            SIMULATION_MODE = True; return
        pred_model  = joblib.load(os.path.join(MODELS_DIR, "best_prediction_model.pkl"))
        pred_scaler = joblib.load(os.path.join(MODELS_DIR, "prediction_scaler.pkl"))
        anom_model  = joblib.load(os.path.join(MODELS_DIR, "bms_isolation_forest.pkl"))
        anom_scaler = joblib.load(os.path.join(MODELS_DIR, "bms_scaler_anomalies.pkl"))
        ANOMALY_FEATURE_COUNT = getattr(anom_scaler, 'n_features_in_',
                                        getattr(anom_model, 'n_features_in_', None))
        print(f"[BMS] All models loaded ✅ prediction features=10 anomaly features={ANOMALY_FEATURE_COUNT}")
    except Exception as e:
        print(f"[BMS] {e} → SIMULATION MODE"); SIMULATION_MODE = True

# ── Flight mode & scenario encoding ───────────────────────────────────────
FLIGHT_MODES   = {"Hover": 0, "Cruise": 1, "Climb": 2, "Descent": 3, "Emergency": 4}
SCENARIO_TYPES = {"Normal": 0, "High Wind": 1, "Low Irradiance": 2, "Emergency": 3, "Performance": 4}

# ── BMS / Physical constants ───────────────────────────────────────────────
BATTERY_WH = 100.0

def get_th():
    s = load_settings()["bms"]
    return {
        "V_MIN":    s["v_crit"],   "V_WARN":   s["v_warn"],
        "I_MAX":    s["i_crit"],   "I_WARN":   s["i_warn"],
        "T_MAX":    s["t_crit"],   "T_WARN":   s["t_warn"],
        "SOC_CRIT": s["soc_crit"],"SOC_LOW":  s["soc_warn"],
        "IRR_LOW":  s["irr_low"],
        "MPPT_CRIT":s.get("mppt_crit", 0.85), "MPPT_WARN":s.get("mppt_warn", 0.88),
        "SOH_CRIT": s.get("soh_crit",  0.015),"SOH_WARN": s.get("soh_warn",  0.010),
    }

# ── Request helpers ───────────────────────────────────────────────────────
def parse_json_request():
    data = request.get_json(silent=True)
    if isinstance(data, dict):
        return data
    try:
        raw = request.data.decode("utf-8")
        return json.loads(raw) if raw else {}
    except Exception:
        return {}

def safe_float(value, default):
    try:
        if value is None or value == "":
            return default
        return float(value)
    except Exception:
        return default

def safe_str(value, default):
    return str(value) if value is not None else default


def normalize_pixhawk_payload(payload):
    if not isinstance(payload, dict):
        return None
    try:
        return {
            "speed": safe_float(payload.get("Speed_ms", payload.get("speed_ms")), 0.0),
            "altitude": safe_float(payload.get("Altitude_m", payload.get("altitude_m")), 0.0),
            "flight_mode": safe_str(payload.get("FlightMode", payload.get("flight_mode", "Cruise")), "Cruise"),
            "wind_speed": safe_float(payload.get("WindSpeed_ms", payload.get("wind_speed_ms")), 0.0),
            "wind_angle_cos": safe_float(payload.get("WindAngle_cos", payload.get("wind_angle_cos")), 0.0),
            "scenario_type": safe_str(payload.get("scenario_type", "Normal"), "Normal"),
            "timestamp": datetime.utcnow().isoformat() + "Z",
        }
    except Exception:
        return None


def normalize_stm32_payload(payload):
    if not isinstance(payload, dict):
        return None
    try:
        voltage = safe_float(payload.get("Voltage_V", payload.get("voltage_v")), 0.0)
        current = safe_float(payload.get("Current_A", payload.get("current_a")), 0.0)
        mppt_eff = safe_float(payload.get("MPPT_eff", payload.get("mppt_eff")), 0.92)
        soh_deg_rate = safe_float(payload.get("SOH_deg_rate", payload.get("soh_deg_rate")), 0.005)
        soc = safe_float(payload.get("SoC_pct", payload.get("soc_pct")), 0.0)
        mission = int(payload.get("Mission", payload.get("mission", 0)))

        voltage = max(12.0, min(16.8, voltage))
        current = max(0.0, min(35.0, current))
        mppt_eff = max(0.80, min(0.99, mppt_eff))
        soc = max(0.0, min(100.0, soc))

        if soh_deg_rate > 1:
            soh_deg_rate = soh_deg_rate / 1000.0
        elif soh_deg_rate > 0.1:
            soh_deg_rate = soh_deg_rate / 100.0
        soh_deg_rate = max(0.001, min(0.02, soh_deg_rate))

        power = safe_float(payload.get("Power_W", payload.get("power_w")), round(voltage * current, 2))
        return {
            "voltage": round(voltage, 2),
            "current": round(current, 2),
            "power": round(power, 2),
            "soc": round(soc, 2),
            "mppt_eff": round(mppt_eff, 4),
            "soh_deg_rate": round(soh_deg_rate, 5),
            "mission": mission,
            "timestamp": datetime.utcnow().isoformat() + "Z",
        }
    except Exception:
        return None


def apply_pixhawk_data(payload):
    parsed = normalize_pixhawk_payload(payload)
    if not parsed:
        return False
    with STATE_LOCK:
        drone_state["flight"].update(parsed)
        drone_state["meta"]["last_pixhawk"] = datetime.utcnow().isoformat() + "Z"
        drone_state["meta"]["source"] = "mavlink"
    return True


def apply_stm32_data(payload):
    parsed = normalize_stm32_payload(payload)
    if not parsed:
        return False
    with STATE_LOCK:
        prev = drone_state["battery"]
        alpha = 0.35
        voltage = prev.get("voltage", parsed["voltage"]) * (1 - alpha) + parsed["voltage"] * alpha
        current = prev.get("current", parsed["current"]) * (1 - alpha) + parsed["current"] * alpha
        soc = prev.get("soc", parsed["soc"]) * (1 - alpha) + parsed["soc"] * alpha
        mppt_eff = prev.get("mppt_eff", parsed["mppt_eff"]) * (1 - alpha) + parsed["mppt_eff"] * alpha
        soh_deg_rate = prev.get("soh_deg_rate", parsed["soh_deg_rate"]) * (1 - alpha) + parsed["soh_deg_rate"] * alpha

        flight = drone_state["flight"]
        flight_bias = 0.0
        if flight.get("flight_mode") in {"Climb", "Hover"}:
            flight_bias += 0.04 * max(0.0, flight.get("speed", 0.0) / 15.0)
        elif flight.get("flight_mode") == "Descent":
            flight_bias -= 0.03
        current = max(0.0, current + flight_bias)

        if current > 1.0:
            soc = max(0.0, min(100.0, soc - 0.004 * current))
        else:
            soc = max(0.0, min(100.0, soc + 0.001))

        parsed = {
            "voltage": round(max(12.0, min(16.8, voltage)), 2),
            "current": round(max(0.0, min(35.0, current)), 2),
            "power": round(max(0.0, voltage * current), 2),
            "soc": round(max(0.0, min(100.0, soc)), 2),
            "mppt_eff": round(max(0.80, min(0.99, mppt_eff)), 4),
            "soh_deg_rate": round(max(0.001, min(0.02, soh_deg_rate)), 5),
            "mission": parsed.get("mission", prev.get("mission", 0)),
            "timestamp": datetime.utcnow().isoformat() + "Z",
        }
        drone_state["battery"].update(parsed)
        drone_state["meta"]["last_stm32"] = datetime.utcnow().isoformat() + "Z"
        drone_state["meta"]["source"] = "stm32"
    return True


def get_latest_state():
    sim = sim_tick()
    with STATE_LOCK:
        battery = dict(drone_state["battery"])
        flight = dict(drone_state["flight"])
        ai = dict(drone_state["ai"])
    merged = {
        "voltage": battery.get("voltage", sim["voltage"]),
        "current": battery.get("current", sim["current"]),
        "power": battery.get("power", sim["power"]),
        "soc": battery.get("soc", sim["soc"]),
        "mppt_eff": battery.get("mppt_eff", sim["mppt_eff"]),
        "soh_deg_rate": battery.get("soh_deg_rate", sim["soh_deg_rate"]),
        "mission": battery.get("mission", 0),
        "speed": flight.get("speed", sim["speed"]),
        "altitude": flight.get("altitude", sim["altitude"]),
        "flight_mode": flight.get("flight_mode", sim["flight_mode"]),
        "wind_speed": flight.get("wind_speed", sim["wind_speed"]),
        "wind_angle_cos": flight.get("wind_angle_cos", sim["wind_angle_cos"]),
        "scenario_type": flight.get("scenario_type", sim["scenario_type"]),
        "irradiance": sim["irradiance"],
        "temperature": sim["temperature"],
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "remaining_energy": ai.get("remaining_energy"),
        "remaining_time": ai.get("remaining_time"),
        "remaining_pct": ai.get("remaining_pct"),
        "risk_level": ai.get("risk_level", "LOW"),
        "recommendation": ai.get("recommendation", "Nominal flight — all systems optimal"),
        "anomaly": ai.get("anomaly", False),
        "anomaly_level": ai.get("anomaly_level", "NORMAL"),
        "anomaly_type": ai.get("anomaly_type", "No anomaly detected"),
        "score_if": ai.get("score_if", 0.0),
        "ml_triggered": ai.get("ml_triggered", False),
        "expert_triggered": ai.get("expert_triggered", False),
    }
    # Mirror the live state into the global state so the UI always has a coherent view.
    with STATE_LOCK:
        drone_state["battery"].setdefault("voltage", merged["voltage"])
        drone_state["battery"].setdefault("current", merged["current"])
        drone_state["battery"].setdefault("power", merged["power"])
        drone_state["battery"].setdefault("soc", merged["soc"])
        drone_state["battery"].setdefault("mppt_eff", merged["mppt_eff"])
        drone_state["battery"].setdefault("soh_deg_rate", merged["soh_deg_rate"])
        drone_state["flight"].setdefault("speed", merged["speed"])
        drone_state["flight"].setdefault("altitude", merged["altitude"])
        drone_state["flight"].setdefault("flight_mode", merged["flight_mode"])
        drone_state["flight"].setdefault("wind_speed", merged["wind_speed"])
        drone_state["flight"].setdefault("wind_angle_cos", merged["wind_angle_cos"])
        drone_state["flight"].setdefault("scenario_type", merged["scenario_type"])
    return merged


def update_ai_state(state):
    try:
        re, rt, rp = run_prediction(
            state["speed"], state["altitude"], state["current"], state["irradiance"],
            state["temperature"], state["soc"], state["flight_mode"],
            state["wind_speed"], state["wind_angle_cos"], state["scenario_type"]
        )
        ia, lv, at, sc, ml, ex = run_anomaly(
            state["current"], state["voltage"], state["power"], state["irradiance"],
            state["mppt_eff"], state["soh_deg_rate"]
        )
        risk, rec = classify_risk(state["soc"], rt, ia, lv)
        payload = {
            "remaining_energy": re,
            "remaining_time": rt,
            "remaining_pct": rp,
            "risk_level": risk,
            "recommendation": rec,
            "anomaly": bool(ia),
            "anomaly_level": lv,
            "anomaly_type": at,
            "score_if": sc,
            "ml_triggered": bool(ml),
            "expert_triggered": bool(ex),
        }
        with STATE_LOCK:
            drone_state["ai"].update(payload)
            drone_state["meta"]["last_ai_update"] = datetime.utcnow().isoformat() + "Z"
            LIVE_HISTORY.append({**state, **payload, "timestamp": datetime.utcnow().isoformat() + "Z"})
    except Exception as exc:
        print(f"[BMS] AI loop error: {exc}")


def listen_udp_packets(port, target):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.settimeout(1.0)
    try:
        sock.bind(("127.0.0.1", port))
    except OSError:
        sock.close()
        return
    while True:
        try:
            data, _ = sock.recvfrom(4096)
        except socket.timeout:
            continue
        except OSError:
            break
        try:
            text = data.decode("utf-8", errors="ignore")
            if not text:
                continue
            payload = json.loads(text)
        except Exception:
            continue
        if target == "pixhawk":
            apply_pixhawk_data(payload)
        else:
            apply_stm32_data(payload)


def listen_mavlink_packets():
    try:
        from pymavlink import mavutil
    except Exception as exc:
        print(f"[BMS] pymavlink unavailable: {exc}")
        return
    try:
        conn = mavutil.mavlink_connection(f"udpin:127.0.0.1:{MAVLINK_UDP_PORT}")
    except Exception as exc:
        print(f"[BMS] MAVLink listener unavailable: {exc}")
        return
    while True:
        try:
            msg = conn.recv_match(blocking=True, timeout=1.0)
            if msg is None:
                continue
            if msg.get_type() == "NAMED_VALUE_FLOAT":
                name = getattr(msg, "name", "")
                value = float(getattr(msg, "value", 0.0))
                if name == "speed_ms":
                    apply_pixhawk_data({"Speed_ms": value})
                elif name == "altitude_m":
                    apply_pixhawk_data({"Altitude_m": value})
                elif name == "flight_mode_code":
                    apply_pixhawk_data({"FlightMode": int(value)})
                elif name == "wind_speed_ms":
                    apply_pixhawk_data({"WindSpeed_ms": value})
                elif name == "wind_angle_cos":
                    apply_pixhawk_data({"WindAngle_cos": value})
                elif name == "scenario_type":
                    apply_pixhawk_data({"scenario_type": int(value)})
        except Exception as exc:
            print(f"[BMS] MAVLink receive error: {exc}")


def autonomous_loop():
    while True:
        try:
            state = get_latest_state()
            update_ai_state(state)
        except Exception as exc:
            print(f"[BMS] autonomous loop error: {exc}")
        time.sleep(5)


def start_background_services():
    global _background_started
    if _background_started:
        return
    _background_started = True
    threading.Thread(target=listen_udp_packets, args=(PIXHAWK_UDP_PORT, "pixhawk"), daemon=True).start()
    threading.Thread(target=listen_udp_packets, args=(STM32_UDP_PORT, "stm32"), daemon=True).start()
    threading.Thread(target=listen_mavlink_packets, daemon=True).start()
    threading.Thread(target=autonomous_loop, daemon=True).start()
    print("[BMS] Autonomous telemetry services started")

# ── Expert rules (battery health & degradation) ───────────────────────────
def expert_rules(soc, temperature, mppt_eff=0.92, soh_deg_rate=0.005):
    TH = get_th()
    a, s = [], []

    if temperature > TH["T_MAX"]:
        a.append("Critical overtemperature"); s.append("CRITICAL")
    elif temperature > TH["T_WARN"]:
        a.append("High temperature warning"); s.append("MODERATE")

    if soc < TH["SOC_CRIT"]:
        a.append("Deep discharge — land immediately"); s.append("CRITICAL")
    elif soc < TH["SOC_LOW"]:
        a.append("Low state of charge"); s.append("MODERATE")

    if mppt_eff < TH["MPPT_CRIT"]:
        a.append("Critical MPPT efficiency drop"); s.append("CRITICAL")
    elif mppt_eff < TH["MPPT_WARN"]:
        a.append("Low MPPT efficiency"); s.append("MODERATE")

    if soh_deg_rate > TH["SOH_CRIT"]:
        a.append("Critical battery degradation rate"); s.append("CRITICAL")
    elif soh_deg_rate > TH["SOH_WARN"]:
        a.append("Elevated degradation rate"); s.append("MODERATE")

    sev = "CRITICAL" if "CRITICAL" in s else ("MODERATE" if "MODERATE" in s else "NORMAL")
    return a, sev

# ── Energy Prediction (10-variable MLP) ───────────────────────────────────
def run_prediction(speed, altitude, current, irradiance, temperature,
                   soc, flight_mode, wind_speed, wind_angle_cos, scenario_type):
    available = BATTERY_WH * (soc / 100.0)
    fm_enc  = FLIGHT_MODES.get(flight_mode,  1)
    sc_enc  = SCENARIO_TYPES.get(scenario_type, 0)

    if SIMULATION_MODE or pred_model is None:
        base_power = current * 14.8
        solar_gain = (irradiance / 1000.0) * 30.0
        wind_drag  = 0.5 * 1.225 * (wind_speed ** 2) * 0.02 * speed
        net_power  = max(base_power - solar_gain + wind_drag, 5.0)
        dE = net_power * (1/60) * random.uniform(0.93, 1.07)
    else:
        features = np.array([[speed, altitude, current, irradiance, temperature,
                               soc, fm_enc, wind_speed, wind_angle_cos, sc_enc]])
        features_scaled = pred_scaler.transform(features)
        dE = max(0.01, float(pred_model.predict(features_scaled)[0]))

    effective_power = max(current * 14.4, 1.0)
    rem_e = max(0.0, available - dE)
    rem_t = round((rem_e / effective_power) * 60.0, 1)
    rem_p = round((rem_e / BATTERY_WH) * 100, 1)
    return round(rem_e, 2), rem_t, rem_p

# ── Anomaly Detection (4-variable Isolation Forest + Expert Rules) ───────
def run_anomaly(current, voltage, power, irradiance, mppt_eff=0.92, soh_deg_rate=0.005):
    """
    Hybrid anomaly detection:
    - Isolation Forest (AI) on 4 variables: Current, Voltage, Power, Irradiance
    - Expert Rules on battery and health metrics: SoC, Temperature, MPPT, SOH
    Final: ANOMALY = ML OR Expert
    """
    temp_proxy = 25 + (current / 30.0) * 35
    soc_proxy  = max(0, min(100, (voltage - 12.0) / 4.8 * 100))

    rules, esev = expert_rules(soc_proxy, temp_proxy, mppt_eff, soh_deg_rate)
    ml, score = False, 0.0
    ml_features = [current, voltage, power, irradiance]

    if not SIMULATION_MODE and anom_model is not None:
        feat = np.array([ml_features])
        if ANOMALY_FEATURE_COUNT and ANOMALY_FEATURE_COUNT != feat.shape[1]:
            print(f"[BMS] Legacy anomaly model compatibility: expected {ANOMALY_FEATURE_COUNT} features, got {feat.shape[1]}")
        try:
            feat_scaled = anom_scaler.transform(feat)
            ml = bool(anom_model.predict(feat_scaled)[0] == -1)
            score = float(round(min(max(-float(anom_model.score_samples(feat_scaled)[0]), 0), 1), 3))
            print(f"[BMS] Anomaly ML input: {ml_features}, score_if={score}, ml={ml}")
        except Exception as ex:
            print(f"[BMS] anomaly model transform/predict failed: {ex}")
            ml = False
            score = round(random.uniform(0.20, 0.45), 3)
    else:
        if rules:
            score = round(random.uniform(0.55, 0.85), 3)
            ml = bool(random.random() > 0.35)
        else:
            score = round(random.uniform(0.08, 0.40), 3)

    expert_triggered = bool(rules)
    is_anom = bool(ml or expert_triggered)
    lvl = ("CRITICAL" if esev == "CRITICAL" else "MODERATE") if is_anom else "NORMAL"
    parts = list(rules)
    if ml and not expert_triggered:
        parts.append("Abnormal electrical behavior detected (ML)")
    atype = ", ".join(parts) if parts else "No anomaly detected"

    print(f"[BMS] Expert rules triggered={expert_triggered}, rules={rules}, fused={is_anom}")
    return is_anom, lvl, atype, score, ml, expert_triggered

def classify_risk(soc, rem_t, is_anom, lvl):
    if lvl == "CRITICAL" or soc < 15 or rem_t < 5:
        return "HIGH", "Immediate landing required"
    if lvl == "MODERATE" or soc < 25 or rem_t < 12:
        return "MEDIUM", "Return to base recommended"
    return "LOW", "Nominal flight — all systems optimal"

# ── Simulation state ───────────────────────────────────────────────────────
_s = dict(soc=80.0, voltage=15.8, current=12.0, temperature=28.0,
          speed=15.0, altitude=120.0, irradiance=650.0,
          wind_speed=3.0, wind_angle_cos=0.85, tick=0,
          mppt_eff=0.93, soh_deg_rate=0.004,
          # MPPT slow oscillation state
          mppt_phase=0.0, soh_base=0.004)

FLIGHT_PHASES = [
    {"mode": "Cruise",  "scenario": "Normal",       "i": 11, "t": 32, "spd": 18, "alt": 120, "irr": 700, "ws": 3.0},
    {"mode": "Climb",   "scenario": "Performance",  "i": 22, "t": 42, "spd": 8,  "alt": 200, "irr": 800, "ws": 5.0},
    {"mode": "Hover",   "scenario": "Normal",       "i": 15, "t": 37, "spd": 0,  "alt": 150, "irr": 650, "ws": 2.0},
    {"mode": "Descent", "scenario": "High Wind",    "i": 8,  "t": 30, "spd": 5,  "alt": 80,  "irr": 500, "ws": 9.0},
]

def sim_tick():
    s = _s
    s["tick"] += 1
    phase = FLIGHT_PHASES[(s["tick"] // 120) % 4]
    a = 0.08

    s["current"]      += a * (phase["i"]   - s["current"])      + random.gauss(0, 0.2)
    s["temperature"]  += a * (phase["t"]   - s["temperature"])  + random.gauss(0, 0.3)
    s["speed"]        += a * (phase["spd"] - s["speed"])        + random.gauss(0, 0.3)
    s["altitude"]     += a * (phase["alt"] - s["altitude"])     + random.gauss(0, 1.0)
    s["irradiance"]   += a * (phase["irr"] - s["irradiance"])   + random.gauss(0, 5.0)
    s["wind_speed"]   += a * (phase["ws"]  - s["wind_speed"])   + random.gauss(0, 0.2)
    s["wind_angle_cos"] = round(math.cos(s["tick"] * 0.05), 3)

    # ── MPPT efficiency: slow sinusoidal + noise (realistic 0.85–0.99)
    s["mppt_phase"] += 0.015
    mppt_target = 0.92 + 0.06 * math.sin(s["mppt_phase"])
    s["mppt_eff"] += 0.05 * (mppt_target - s["mppt_eff"]) + random.gauss(0, 0.003)
    s["mppt_eff"] = round(max(0.82, min(0.99, s["mppt_eff"])), 4)

    # ── SOH degradation rate: slow ramp with occasional spikes
    s["soh_deg_rate"] += random.gauss(0, 0.0001)
    if random.random() < 0.02:           # 2% chance of a spike
        s["soh_deg_rate"] += random.uniform(0.003, 0.008)
    s["soh_deg_rate"] = round(max(0.001, min(0.02, s["soh_deg_rate"])), 5)

    s["current"]     = max(2,   min(32,   s["current"]))
    s["temperature"] = max(20,  min(65,   s["temperature"]))
    s["speed"]       = max(0,   min(30,   s["speed"]))
    s["altitude"]    = max(10,  min(300,  s["altitude"]))
    s["irradiance"]  = max(0,   min(1000, s["irradiance"]))
    s["wind_speed"]  = max(0,   min(15,   s["wind_speed"]))

    s["soc"]     = max(0, s["soc"] - 0.04 * (s["current"] / 10))
    s["voltage"] = max(12, min(16.8, 12 + (s["soc"] / 100) * 4.8 + random.gauss(0, 0.05)))
    power = round(s["voltage"] * s["current"], 1)

    return {
        "speed":          round(s["speed"], 1),
        "altitude":       round(s["altitude"], 1),
        "current":        round(s["current"], 2),
        "irradiance":     round(s["irradiance"], 1),
        "temperature":    round(s["temperature"], 1),
        "soc":            round(s["soc"], 1),
        "flight_mode":    phase["mode"],
        "wind_speed":     round(s["wind_speed"], 2),
        "wind_angle_cos": s["wind_angle_cos"],
        "scenario_type":  phase["scenario"],
        "voltage":        round(s["voltage"], 2),
        "power":          power,
        "mppt_eff":       s["mppt_eff"],
        "soh_deg_rate":   s["soh_deg_rate"],
    }

# ── Database ───────────────────────────────────────────────────────────────
def init_db():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    cur.execute("""CREATE TABLE IF NOT EXISTS telemetry (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        mission_id TEXT,
        current REAL, voltage REAL, power REAL, irradiance REAL,
        temperature REAL, soc REAL, speed REAL, altitude REAL,
        remaining_energy REAL, remaining_time REAL,
        anomaly_status INTEGER, anomaly_score REAL, anomaly_level TEXT,
        mppt_eff REAL, soh_deg_rate REAL,
        flight_mode TEXT, risk_level TEXT
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS missions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mission_id TEXT UNIQUE,
        start_time TEXT, end_time TEXT,
        duration_min REAL,
        avg_power REAL, avg_current REAL, avg_irradiance REAL,
        avg_temperature REAL, initial_soc REAL, final_soc REAL,
        energy_consumed REAL, remaining_energy REAL,
        anomaly_count INTEGER, final_risk TEXT, status TEXT
    )""")

    con.commit(); con.close()

init_db()

# Active mission tracking
_mission = {"id": None, "start": None, "ticks": 0}

def get_or_create_mission():
    if _mission["id"] is None:
        _mission["id"]    = f"MSN-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}"
        _mission["start"] = datetime.utcnow().isoformat()
        _mission["ticks"] = 0
    _mission["ticks"] += 1
    return _mission["id"]

def log_telemetry(data):
    mid = get_or_create_mission()
    ts  = datetime.utcnow().isoformat()
    con = sqlite3.connect(DB_PATH)
    con.execute("""INSERT INTO telemetry
        (timestamp, mission_id, current, voltage, power, irradiance,
         temperature, soc, speed, altitude, remaining_energy, remaining_time,
         anomaly_status, anomaly_score, anomaly_level, mppt_eff, soh_deg_rate,
         flight_mode, risk_level)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (ts, mid, data.get("current",0), data.get("voltage",0),
         data.get("power",0), data.get("irradiance",0), data.get("temperature",0),
         data.get("soc",0), data.get("speed",0), data.get("altitude",0),
         data.get("remaining_energy",0), data.get("remaining_time",0),
         1 if data.get("anomaly") else 0, data.get("score_if",0),
         data.get("anomaly_level","NORMAL"), data.get("mppt_eff",0.92),
         data.get("soh_deg_rate",0.005), data.get("flight_mode","Cruise"),
         data.get("risk_level","LOW")))
    con.commit(); con.close()

def finalize_mission(mission_id):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    rows = cur.execute("""SELECT current, power, irradiance, temperature,
        soc, remaining_energy, remaining_time, anomaly_status, risk_level,
        timestamp FROM telemetry WHERE mission_id=? ORDER BY timestamp""",
        (mission_id,)).fetchall()
    if not rows: con.close(); return

    currents = [r[0] for r in rows]
    powers   = [r[1] for r in rows]
    irrs     = [r[2] for r in rows]
    temps    = [r[3] for r in rows]
    socs     = [r[4] for r in rows]

    init_soc  = socs[0] if socs else 0
    final_soc = socs[-1] if socs else 0
    n_anom    = sum(r[7] for r in rows)
    risk_counts = {}
    for r in rows:
        risk_counts[r[8]] = risk_counts.get(r[8], 0) + 1
    final_risk = max(risk_counts, key=risk_counts.get) if risk_counts else "LOW"

    start_t   = rows[0][9]
    end_t     = rows[-1][9]
    try:
        dur_min = (datetime.fromisoformat(end_t) - datetime.fromisoformat(start_t)).total_seconds() / 60
    except Exception:
        dur_min = len(rows) / 60

    energy_consumed = init_soc - final_soc  # proxy in %

    cur.execute("""INSERT OR REPLACE INTO missions
        (mission_id, start_time, end_time, duration_min,
         avg_power, avg_current, avg_irradiance, avg_temperature,
         initial_soc, final_soc, energy_consumed, remaining_energy,
         anomaly_count, final_risk, status)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (mission_id, start_t, end_t, round(dur_min, 2),
         round(sum(powers)/len(powers), 1), round(sum(currents)/len(currents), 2),
         round(sum(irrs)/len(irrs), 1), round(sum(temps)/len(temps), 1),
         round(init_soc, 1), round(final_soc, 1),
         round(energy_consumed, 2), round(rows[-1][5], 2),
         n_anom, final_risk, "Completed"))
    con.commit(); con.close()

# ── Auth decorator ─────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def dec(*a, **kw):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*a, **kw)
    return dec

# ═══════════════════════════════════════════════════════════════════════════
# PAGE ROUTES
# ═══════════════════════════════════════════════════════════════════════════

@app.route("/")
def index():
    return redirect(url_for("prediction") if "user" in session else url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        user = USERS.get(u)
        if user and user["password"] == p:
            session.update(user=u, full_name=user["full_name"], role=user["role"])
            return redirect(url_for("prediction"))
        error = "Invalid credentials. Please try again."
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    # Finalize active mission on logout
    if _mission["id"]:
        finalize_mission(_mission["id"])
        _mission["id"] = None
    session.clear()
    return redirect(url_for("login"))

@app.route("/prediction")
@login_required
def prediction():
    return render_template("prediction.html",
        user=session["full_name"], role=session["role"], sim=SIMULATION_MODE)

@app.route("/anomaly")
@login_required
def anomaly():
    return render_template("anomaly.html",
        user=session["full_name"], role=session["role"], sim=SIMULATION_MODE)

@app.route("/reports")
@login_required
def reports():
    return render_template("reports.html",
        user=session["full_name"], role=session["role"], sim=SIMULATION_MODE)

@app.route("/settings")
@login_required
def settings():
    s = load_settings()
    return render_template("settings.html",
        user=session["full_name"], role=session["role"],
        sim=SIMULATION_MODE, settings=s)

# ═══════════════════════════════════════════════════════════════════════════
# API — PREDICTION
# ═══════════════════════════════════════════════════════════════════════════

@app.route("/api/predict", methods=["POST"])
@login_required
def api_predict():
    try:
        d = parse_json_request() or {}
        state = get_latest_state()

        if not d:
            print("[API] /api/predict payload missing or empty → using autonomous state")
        else:
            print(f"[API] /api/predict received payload keys={list(d.keys())}")
            for key, value in d.items():
                if value is not None and value != "":
                    state[key] = value

        speed = safe_float(state.get("speed"), state.get("speed", 0.0))
        altitude = safe_float(state.get("altitude"), state.get("altitude", 0.0))
        current = safe_float(state.get("current"), state.get("current", 0.0))
        irradiance = safe_float(state.get("irradiance"), state.get("irradiance", 0.0))
        temperature = safe_float(state.get("temperature"), state.get("temperature", 25.0))
        soc = safe_float(state.get("soc"), state.get("soc", 0.0))
        flight_mode = safe_str(state.get("flight_mode"), "Cruise")
        wind_speed = safe_float(state.get("wind_speed"), state.get("wind_speed", 0.0))
        wind_angle_cos = safe_float(state.get("wind_angle_cos"), state.get("wind_angle_cos", 0.0))
        scenario_type = safe_str(state.get("scenario_type"), "Normal")
        voltage = safe_float(state.get("voltage"), state.get("voltage", 14.8))
        power = safe_float(state.get("power"), round(voltage * current, 1))
        mppt_eff = safe_float(state.get("mppt_eff"), state.get("mppt_eff", 0.92))
        soh_deg_rate = safe_float(state.get("soh_deg_rate"), state.get("soh_deg_rate", 0.005))

        v = {
            "speed": speed,
            "altitude": altitude,
            "current": current,
            "irradiance": irradiance,
            "temperature": temperature,
            "soc": soc,
            "flight_mode": flight_mode,
            "wind_speed": wind_speed,
            "wind_angle_cos": wind_angle_cos,
            "scenario_type": scenario_type,
            "voltage": voltage,
            "power": power,
            "mppt_eff": mppt_eff,
            "soh_deg_rate": soh_deg_rate,
        }

        re, rt, rp = run_prediction(
            v["speed"], v["altitude"], v["current"], v["irradiance"],
            v["temperature"], v["soc"], v["flight_mode"],
            v["wind_speed"], v["wind_angle_cos"], v["scenario_type"]
        )
        ia, lv, at, sc, ml, ex = run_anomaly(
            v["current"], v["voltage"], v["power"],
            v["irradiance"], v["mppt_eff"], v["soh_deg_rate"]
        )
        risk, rec = classify_risk(v["soc"], rt, ia, lv)

        out = {**v,
            "remaining_energy": re, "remaining_time": rt,
            "remaining_pct": rp, "risk_level": risk, "recommendation": rec,
            "anomaly": bool(ia), "anomaly_level": lv, "anomaly_type": at,
            "score_if": sc, "ml_triggered": bool(ml), "expert_triggered": bool(ex),
            "anomaly_model_features": int(ANOMALY_FEATURE_COUNT) if ANOMALY_FEATURE_COUNT is not None else None,
            "anomaly_model_mode": "legacy" if ANOMALY_FEATURE_COUNT and ANOMALY_FEATURE_COUNT != 4 else "modern",
            "simulation_mode": bool(SIMULATION_MODE),
            "timestamp": datetime.utcnow().isoformat() + "Z"}

        log_telemetry(out)
        return jsonify(out)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

# ═══════════════════════════════════════════════════════════════════════════
# API — ANOMALY DETECTION (4-variable Isolation Forest + Expert Rules)
# ═══════════════════════════════════════════════════════════════════════════

@app.route("/api/anomaly", methods=["POST"])
@login_required
def api_anomaly():
    try:
        d = parse_json_request() or {}
        state = get_latest_state()

        if not d:
            print("[API] /api/anomaly payload missing or empty → using autonomous state")
        else:
            print(f"[API] /api/anomaly received payload keys={list(d.keys())}")
            for key, value in d.items():
                if value is not None and value != "":
                    state[key] = value

        current = safe_float(state.get("current"), state.get("current", 0.0))
        voltage = safe_float(state.get("voltage"), state.get("voltage", 14.8))
        irradiance = safe_float(state.get("irradiance"), state.get("irradiance", 0.0))
        mppt_eff = safe_float(state.get("mppt_eff"), state.get("mppt_eff", 0.92))
        soh_deg_rate = safe_float(state.get("soh_deg_rate"), state.get("soh_deg_rate", 0.005))
        power = safe_float(state.get("power"), round(voltage * current, 1))

        v = {
            "current": current,
            "voltage": voltage,
            "power": power,
            "irradiance": irradiance,
            "mppt_eff": mppt_eff,
            "soh_deg_rate": soh_deg_rate,
        }

        ia, lv, at, sc, ml, ex = run_anomaly(**v)
        soc_proxy = max(0, min(100, (v["voltage"] - 12) / 4.8 * 100))
        temp_proxy = 25 + (v["current"] / 30) * 35
        rules, _ = expert_rules(soc_proxy, temp_proxy, v["mppt_eff"], v["soh_deg_rate"])

        out = {**v,
            "soc": soc_proxy,
            "temperature": temp_proxy,
            "anomaly": bool(ia), "anomaly_level": lv, "anomaly_type": at,
            "score_if": sc, "ml_triggered": bool(ml), "expert_triggered": bool(ex),
            "expert_rules": rules,
            "anomaly_model_features": int(ANOMALY_FEATURE_COUNT) if ANOMALY_FEATURE_COUNT is not None else None,
            "anomaly_model_mode": "legacy" if ANOMALY_FEATURE_COUNT and ANOMALY_FEATURE_COUNT != 4 else "modern",
            "simulation_mode": bool(SIMULATION_MODE),
            "timestamp": datetime.utcnow().isoformat() + "Z"}

        log_telemetry(out)
        return jsonify(out)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

# ═══════════════════════════════════════════════════════════════════════════
# API — REPORTS
# ═══════════════════════════════════════════════════════════════════════════

@app.route("/api/reports/summary")
@login_required
def api_reports_summary():
    try:
        con = sqlite3.connect(DB_PATH)
        cur = con.cursor()

        total_missions = cur.execute("SELECT COUNT(*) FROM missions").fetchone()[0]
        total_hours    = cur.execute("SELECT SUM(duration_min)/60 FROM missions").fetchone()[0] or 0
        avg_power      = cur.execute("SELECT AVG(avg_power) FROM missions").fetchone()[0] or 0
        total_anomalies= cur.execute("SELECT SUM(anomaly_count) FROM missions").fetchone()[0] or 0
        avg_soc_change = cur.execute("SELECT AVG(initial_soc - final_soc) FROM missions").fetchone()[0] or 0
        avg_mppt       = cur.execute("SELECT AVG(mppt_eff) FROM telemetry").fetchone()[0] or 0.92
        avg_soh        = cur.execute("SELECT AVG(soh_deg_rate) FROM telemetry").fetchone()[0] or 0.005

        # Battery health trend (last 10 missions avg soc efficiency)
        health_rows = cur.execute(
            "SELECT final_soc FROM missions ORDER BY start_time DESC LIMIT 10"
        ).fetchall()
        health_trend = [round(r[0], 1) for r in reversed(health_rows)]

        con.close()
        return jsonify({
            "total_missions":    total_missions,
            "total_hours":       round(total_hours, 2),
            "avg_power":         round(avg_power, 1),
            "total_anomalies":   int(total_anomalies),
            "avg_soc_change":    round(avg_soc_change, 2),
            "avg_mppt":          round(avg_mppt, 4),
            "avg_soh_deg":       round(avg_soh, 5),
            "battery_health_trend": health_trend,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/reports/missions")
@login_required
def api_reports_missions():
    try:
        page = int(request.args.get("page", 1))
        limit = int(request.args.get("limit", 20))
        offset = (page - 1) * limit
        search = request.args.get("search", "")

        con = sqlite3.connect(DB_PATH)
        cur = con.cursor()

        query = "SELECT * FROM missions"
        params = []
        if search:
            query += " WHERE mission_id LIKE ? OR final_risk LIKE ? OR status LIKE ?"
            params = [f"%{search}%"] * 3

        total = cur.execute(f"SELECT COUNT(*) FROM ({query})", params).fetchone()[0]
        query += " ORDER BY start_time DESC LIMIT ? OFFSET ?"
        params += [limit, offset]
        rows = cur.execute(query, params).fetchall()
        cols = [d[0] for d in cur.description]
        missions = [dict(zip(cols, r)) for r in rows]
        con.close()

        return jsonify({"missions": missions, "total": total, "page": page})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/reports/charts")
@login_required
def api_reports_charts():
    try:
        days = int(request.args.get("days", 7))
        cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()

        con = sqlite3.connect(DB_PATH)
        cur = con.cursor()

        # Telemetry time-series (sampled every 30 rows)
        rows = cur.execute("""
            SELECT timestamp, power, soc, irradiance, anomaly_score,
                   mppt_eff, soh_deg_rate
            FROM telemetry WHERE timestamp > ?
            ORDER BY timestamp
        """, (cutoff,)).fetchall()

        # Sample to max 200 pts
        step = max(1, len(rows) // 200)
        sampled = rows[::step]

        labels    = [r[0][11:19] for r in sampled]   # HH:MM:SS
        power     = [round(r[1], 1) for r in sampled]
        soc       = [round(r[2], 1) for r in sampled]
        irradiance= [round(r[3], 1) for r in sampled]
        anom_score= [round(r[4], 3) for r in sampled]
        mppt      = [round(r[5], 4) for r in sampled]
        soh       = [round(r[6], 5) for r in sampled]

        # Anomaly frequency per mission
        anom_freq = cur.execute("""
            SELECT mission_id, anomaly_count FROM missions
            ORDER BY start_time DESC LIMIT 15
        """).fetchall()

        con.close()
        return jsonify({
            "labels": labels, "power": power, "soc": soc,
            "irradiance": irradiance, "anomaly_score": anom_score,
            "mppt": mppt, "soh": soh,
            "anom_freq_labels": [r[0] for r in anom_freq],
            "anom_freq_values": [r[1] for r in anom_freq],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Export routes ──────────────────────────────────────────────────────────
@app.route("/api/reports/export/csv")
@login_required
def export_csv():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    rows = cur.execute("SELECT * FROM missions ORDER BY start_time DESC").fetchall()
    cols = [d[0] for d in cur.description]
    con.close()

    buf = StringIO()
    writer = csv.writer(buf)
    writer.writerow(cols)
    writer.writerows(rows)
    buf.seek(0)
    return send_file(
        BytesIO(buf.getvalue().encode()),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"bms_missions_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
    )

@app.route("/api/reports/export/json")
@login_required
def export_json():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    rows = cur.execute("SELECT * FROM missions ORDER BY start_time DESC").fetchall()
    cols = [d[0] for d in cur.description]
    con.close()
    missions = [dict(zip(cols, r)) for r in rows]
    buf = BytesIO(json.dumps(missions, indent=2).encode())
    buf.seek(0)
    return send_file(buf, mimetype="application/json", as_attachment=True,
                     download_name=f"bms_missions_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json")

@app.route("/api/reports/mission/<mission_id>/end", methods=["POST"])
@login_required
def end_mission(mission_id):
    finalize_mission(mission_id)
    if _mission["id"] == mission_id:
        _mission["id"] = None
    return jsonify({"status": "ok", "mission_id": mission_id})

# ═══════════════════════════════════════════════════════════════════════════
# API — SETTINGS
# ═══════════════════════════════════════════════════════════════════════════

@app.route("/api/settings", methods=["GET"])
@login_required
def api_settings_get():
    return jsonify(load_settings())

@app.route("/api/settings", methods=["POST"])
@login_required
def api_settings_post():
    try:
        data = request.get_json(silent=True) or {}
        current = load_settings()

        # Deep merge
        for section, vals in data.items():
            if section in current and isinstance(vals, dict):
                current[section].update(vals)
            else:
                current[section] = vals

        save_settings(current)
        return jsonify({"status": "saved", "settings": current})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/settings/reset", methods=["POST"])
@login_required
def api_settings_reset():
    save_settings(dict(DEFAULT_SETTINGS))
    return jsonify({"status": "reset", "settings": DEFAULT_SETTINGS})

# ── Status ─────────────────────────────────────────────────────────────────
@app.route("/api/status")
def api_status():
    return jsonify({
        "status": "online",
        "simulation_mode": SIMULATION_MODE,
        "active_mission": _mission["id"],
        "autonomous": True,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })

@app.route("/api/live")
def api_live():
    return jsonify(get_latest_state())

# ── Seed some demo mission data if DB is empty ─────────────────────────────
def seed_demo_data():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    count = cur.execute("SELECT COUNT(*) FROM missions").fetchone()[0]
    con.close()
    if count > 0:
        return

    print("[BMS] Seeding demo mission data...")
    import random as rnd
    base_time = datetime.utcnow() - timedelta(days=14)
    for i in range(20):
        mid = f"MSN-DEMO-{i+1:03d}"
        st  = (base_time + timedelta(hours=i * 16)).isoformat()
        dur = rnd.uniform(20, 90)
        et  = (datetime.fromisoformat(st) + timedelta(minutes=dur)).isoformat()
        n_anom = rnd.randint(0, 12)
        risk = rnd.choice(["LOW", "LOW", "MEDIUM", "HIGH"])
        isoc = rnd.uniform(85, 100)
        fsoc = isoc - rnd.uniform(15, 45)

        con = sqlite3.connect(DB_PATH)
        con.execute("""INSERT OR IGNORE INTO missions
            (mission_id, start_time, end_time, duration_min,
             avg_power, avg_current, avg_irradiance, avg_temperature,
             initial_soc, final_soc, energy_consumed, remaining_energy,
             anomaly_count, final_risk, status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (mid, st, et, round(dur, 1),
             round(rnd.uniform(120, 320), 1), round(rnd.uniform(8, 22), 2),
             round(rnd.uniform(400, 900), 1), round(rnd.uniform(28, 48), 1),
             round(isoc, 1), round(max(10, fsoc), 1),
             round(isoc - max(10, fsoc), 2), round(max(5, fsoc * BATTERY_WH / 100), 2),
             n_anom, risk, "Completed"))
        con.commit()

        # Add some telemetry points for charts
        for j in range(30):
            ts = (datetime.fromisoformat(st) + timedelta(seconds=j*60)).isoformat()
            soc_v = isoc - (isoc - max(10, fsoc)) * j / 30
            con.execute("""INSERT INTO telemetry
                (timestamp, mission_id, current, voltage, power, irradiance,
                 temperature, soc, speed, altitude, remaining_energy, remaining_time,
                 anomaly_status, anomaly_score, anomaly_level, mppt_eff, soh_deg_rate,
                 flight_mode, risk_level)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (ts, mid, rnd.uniform(8,22), rnd.uniform(13,16.5),
                 rnd.uniform(100,350), rnd.uniform(300,950),
                 rnd.uniform(28,50), soc_v, rnd.uniform(0,25), rnd.uniform(50,250),
                 soc_v*BATTERY_WH/100, soc_v*3,
                 1 if rnd.random()<0.1 else 0, rnd.uniform(0.05,0.45),
                 "NORMAL", rnd.uniform(0.87,0.97), rnd.uniform(0.002,0.012),
                 rnd.choice(["Cruise","Hover","Climb","Descent"]), risk))
        con.commit(); con.close()

    print("[BMS] Demo data seeded ✅")

if __name__ == "__main__":
    load_models()
    seed_demo_data()
    start_background_services()
    print("[BMS] Running on http://127.0.0.1:5000")
    app.run(debug=True, host="0.0.0.0", port=5000)
